//
//  IBBasicViewController.h
//  YJSliderView
//
//  Created by jakey on 2017/6/30.
//  Copyright © 2017年 Jake. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IBBasicViewController : UIViewController

@end
